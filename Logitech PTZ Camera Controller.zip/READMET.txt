Logitech PTZ Camera Controller
------------------------------

Freeware created out of necessity, this little guy allows you to control the
Pan-Tilt-Zoom of a Logitech " & DEVICE_NAME & " using on-screen buttons or
the arrow-keys & home-end (for zoom)


Uses the PTZ System library:
https://github.com/shanselman/PanTiltZoomSystem/


Copyright 2015 - SG57 Productions